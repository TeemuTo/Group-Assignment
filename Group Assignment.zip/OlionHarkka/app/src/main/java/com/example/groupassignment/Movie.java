package com.example.groupassignment;

public class Movie {
    private String movie;
    private String duration;
    private String genre;
    private String rating;

    public Movie(String m, String d,String r,String g){
        movie = m;
        duration = d;
        rating = r;
        genre = g;
    }

    @Override
    public String toString() {
        return "Show{" +
                "Title='" + movie + '\'' +
                ", LengthInMinutes='" + duration + '\'' +
                ", Rating='" + rating + '\'' +
                ", Genres='" + genre + '\'' +
                '}';
    }

    public String getFilm(){return movie;}
    public String getDuration(){return duration;}
    public String getRating(){return rating;}
    public String getStory(){return genre;}

    public void setTitle(String m) {
        this.movie = m;
    }

    public void setLengthInMinutes(String d) {
        this.duration = d;
    }

    public void setGenres(String g) {
        this.genre = g;
    }
}
