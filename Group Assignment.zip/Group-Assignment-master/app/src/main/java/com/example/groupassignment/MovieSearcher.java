package com.example.groupassignment;

import static android.R.layout.*;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.DocumentsContract;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


public class MovieSearcher extends AppCompatActivity {

    ArrayList showlist = new ArrayList();
    String theatre = getIntent().getStringExtra("theatre");
    String d = getIntent().getStringExtra("date");

    Date date;

    {
        try {
            date = new SimpleDateFormat("dd/MM/yyyy").parse(d);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_searcher);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


    }

    public class XMLParsing extends Activity {

        /* Get Document Builder
        *Get Document
        * Normalize the xml structure
        * *Get all of the wanted elements by tag name
         */
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        {
            try {
                builder = factory.newDocumentBuilder();

                //get document
                Document doc = builder.parse( new File("https://www.finnkino.fi/xml/Schedule/"));

                //Normalize the xml structure

                doc.getDocumentElement().normalize();

                //Get wanted elements by tag name

                NodeList showList = doc.getElementsByTagName("Shows");

                for (int i = 0; i<showList.getLength() ; i++) {
                    Node show = showList.item(i);

                    if (show.getNodeType() == Node.ELEMENT_NODE) {
                        Element showElement = (Element)  show;

                        NodeList showDetails = show.getChildNodes();
                        for (int j = 0; j <showDetails.getLength();j++){
                            Node detail = showDetails.item(j);
                            if (detail.getNodeType() == Node.ELEMENT_NODE) {
                                Element detailElement = (Element)  detail;

                                if( showElement.getAttribute("Theatre") == theatre){
                                    Date start = new SimpleDateFormat("yyyy-MM-d'T'HH:mm").parse(showElement.getAttribute("dttmShowStart"));
                                    if (start == date){
                                        showlist.add(showElement.getAttribute("Title"));
                                        showlist.add(new SimpleDateFormat("yyyy-MM-d'T'HH:mm").parse(showElement.getAttribute("dttmShowStart")).toString());
                                        showlist.add(showElement.getAttribute("Theatre"));
                                        showlist.add(showElement.getAttribute("Rating"));
                                        showlist.add(showElement.getAttribute("LengthInMinutes"));
                                        showlist.add(showElement.getAttribute("ShowURL"));
                                        showlist.add(showElement.getElementsByTagNameNS("Images", "EventMediumImagePortrait"));
                                    }

                                }
                            }
                        }


                    }
                }
               Spinner sp3 = (Spinner) findViewById(R.id.spinner3);
                ArrayAdapter<String> parseAdapter= new ArrayAdapter<String>(MovieSearcher.this,android.R.layout.simple_list_item_1,showlist);
                parseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sp3.setAdapter(parseAdapter);
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }




    }

    }
