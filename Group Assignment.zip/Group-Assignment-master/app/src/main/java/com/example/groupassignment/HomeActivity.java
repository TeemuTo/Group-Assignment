package com.example.groupassignment;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class HomeActivity extends AppCompatActivity {

    ListView searchlist;
    ImageButton settings;
    Toolbar toolbar;

    Button movieButton;

    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> name;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);


        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openWebview();
            }
        });
        toolbar = (Toolbar) findViewById(R.id.HomeToolbar);
        setSupportActionBar(toolbar);

        name = new ArrayList<>();
        name.add("Teemu");
        name.add("Henri");
        name.add("Jyri");
        name.add("Wenla");


        searchlist = findViewById(R.id.searchlist);
        settings = (ImageButton) findViewById(R.id.settings);


        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, SettingsActivity.class));
            }
        });

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, name);

        searchlist.setAdapter(arrayAdapter);

        Spinner sp = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<String> movieAdapter = new ArrayAdapter<String>(HomeActivity.this,android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.leffalista));
        movieAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter((movieAdapter));

       Spinner sp2 = (Spinner) findViewById(R.id.spinner2);

        int i=0;
        List lista = new ArrayList<>();
        while ( i <= 7) {
            final LocalDate date = LocalDate.now();
            final LocalDate plusdays = date.plusDays(i);
            final  String formattedDate = plusdays.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            lista.add(formattedDate);
            i++;
        }

        ArrayAdapter<Date> dateAdapter = new ArrayAdapter<Date>(HomeActivity.this,android.R.layout.simple_list_item_1,lista);
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp2.setAdapter((dateAdapter));



        movieButton = (Button) findViewById(R.id.button2);
        movieButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                String theatre = sp.getSelectedItem().toString();
                String date = sp2.getSelectedItem().toString();
                Intent intent = new Intent(HomeActivity.this, MovieSearcher.class);
                intent.putExtra("theatre", theatre);
                intent.putExtra("date", date);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);

        MenuItem menuitem = menu.findItem(R.id.search);
        SearchView searchview = (SearchView) menuitem.getActionView();
        searchview.setQueryHint("Type here to search movies");

        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                arrayAdapter.getFilter().filter(newText);
                if(newText.isEmpty()){
                    searchlist.setVisibility(View.GONE);
                }
                else{
                    searchlist.setVisibility(View.VISIBLE);
                }
                return false;
            }
        });
        searchlist.setVisibility(View.GONE);
        return super.onCreateOptionsMenu(menu);
    }
    public void openWebview(){
        Intent intent = new Intent(this, Webview.class);
        startActivity(intent);
    }
}